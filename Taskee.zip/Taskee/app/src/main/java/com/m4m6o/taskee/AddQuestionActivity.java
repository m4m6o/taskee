package com.m4m6o.taskee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.Normalizer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class AddQuestionActivity extends AppCompatActivity implements View.OnClickListener {

    Button backBtn, applyBtn;
    EditText theme, question, coins;
    CheckBox quick;
    TextView balance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_question);

        backBtn  = findViewById(R.id.backBtn);
        applyBtn = findViewById(R.id.ApplyBtn);
        theme    = findViewById(R.id.ThemeOfQuestion);
        question = findViewById(R.id.question);
        coins    = findViewById(R.id.coinsText);
        quick    = findViewById(R.id.QRCheckBox);
        balance  = findViewById(R.id.balance);

        backBtn.setOnClickListener(this);
        applyBtn.setOnClickListener(this);
        quick.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.backBtn){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (v.getId() == R.id.ApplyBtn){
            /* apply question */
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (v.getId() == R.id.QRCheckBox){
            if (coins.isEnabled()){
                balance.setEnabled(false);
                coins.setEnabled(false);
            } else {
                balance.setEnabled(true);
                coins.setEnabled(true);
            }
        }
    }
}
