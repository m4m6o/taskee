package com.m4m6o.taskee;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION   = 1;
    public static final String DATABASE_NAME   = "taskee_database";
    public static final String TABLE_USERS     = "users";
    public static final String TABLE_MESSAGES  = "msg";
    public static final String TABLE_QUESTIONS = "questions";
    public static final String TABLE_COMMENTS  = "comments";

    public static final String KEY_ID     = "_id";
    public static final String KEY_NAME   = "name";
    public static final String KEY_COINS  = "coins";
    public static final String KEY_LOGIN  = "login";
    public static final String KEY_PASSWD = "passwd";

    public static final String KEY_USER1  = "name1";
    public static final String KEY_USER2  = "name2";
    public static final String KEY_TEXT   = "text";

    public static final String KEY_THEME  = "theme";
    public static final String KEY_QUES   = "question";
    public static final String KEY_DATE   = "date";
    public static final String KEY_STATUS = "status";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table users (id integer primary key, name text, coins text, login text, passwd text, info text);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TABLE_USERS);
        onCreate(db);
    }

    //тут добавил немного индуского программирования
    public boolean insert(String name, String login, String passwd){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_NAME, name);
        contentValues.put(KEY_COINS, 100);
        contentValues.put(KEY_LOGIN, login);
        contentValues.put(KEY_PASSWD, passwd);
        long ins = database.insert(TABLE_USERS, null, contentValues);
        if (ins == -1) return false;
        else return true;
    }

    //и тут
    public boolean checkLogin(String login){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select * from " + TABLE_USERS + " where login=?", new String[]{login});
        if (cursor.getCount()>0) return false;
        else return true;
    }

    //и тут тоже
    public boolean loginpasswd(String login, String passwd){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select * from " + TABLE_USERS + " where login=? and passwd=?", new String[]{login, passwd});
        if (cursor.getCount()>0) return true;
        else return false;
    }

    //и тут что-то среднее
    public String getCoins(String login){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select coins from " + TABLE_USERS + " where login=?", new String[]{login});
        if (cursor.moveToFirst()){
            if (cursor.getCount()>0){
                return cursor.getString(0);
            }
        }
        return "100";
    }
    public String getName(String login){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select name from " + TABLE_USERS + " where login=?", new String[]{login});
        if (cursor.moveToFirst()) {
            if (cursor.getCount() > 0) {
                return cursor.getString(0);
            }
        }
        return "Error";
    }

    public String getInfo(String login){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select info from " + TABLE_USERS + " where login=?", new String[]{login});
        if (cursor.moveToFirst()) {
            if (cursor.getCount() > 0) {
                return cursor.getString(0);
            }
        }
        return "About " + getName(login);
    }
}
