package com.m4m6o.taskee;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button regBtn, logBtn;
    EditText login, passwd;
    DBHelper dbHelper;
    SQLiteDatabase database;
    ContentValues contentValues;
    SharedPreferences sharedPreferences;

    final String SAVED_LOGIN  = "saved_login";
    final String SAVED_PASSWD = "saved_password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        regBtn = findViewById(R.id.regBtn);
        logBtn = findViewById(R.id.logBtn);
        login  = findViewById(R.id.login);
        passwd = findViewById(R.id.passwd);

        regBtn.setOnClickListener(this);
        logBtn.setOnClickListener(this);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.regBtn){
            Intent intent = new Intent(this, RegisterActivity.class);
            startActivity(intent);
        } else if (v.getId() == R.id.logBtn){
            String loginText = login.getText().toString();
            String passwdText = passwd.getText().toString();

            database = dbHelper.getWritableDatabase();
            contentValues = new ContentValues();

            if (dbHelper.loginpasswd(loginText, passwdText)){
                sharedPreferences = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("name", dbHelper.getName(loginText));
                editor.putString(SAVED_LOGIN, loginText);
                editor.putString(SAVED_PASSWD, passwdText);
                editor.putString("coins", dbHelper.getCoins(loginText));
                editor.apply();

                Toast.makeText(this, "Successfully login", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            } else {
                Toast toast = Toast.makeText(LoginActivity.this, "Incorrect username or password", Toast.LENGTH_LONG);
                toast.show();
            }
        }
    }
}
