package com.m4m6o.taskee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button AQBtn, QBtn, MPBtn, CBtn, SBtn;
    TextView balance;
    Intent intent;
    SharedPreferences sharedPreferences;
    String name, login, password, coins;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AQBtn = findViewById(R.id.AddQuestionBtn);
        QBtn  = findViewById(R.id.QuestionsBtn);
        MPBtn = findViewById(R.id.MyProfileBtn);
        CBtn  = findViewById(R.id.ChatsBtn);
        SBtn  = findViewById(R.id.SettingsBtn);

        balance = findViewById(R.id.coins);

        AQBtn.setOnClickListener(this);
        QBtn.setOnClickListener(this);
        MPBtn.setOnClickListener(this);
        CBtn.setOnClickListener(this);
        SBtn.setOnClickListener(this);

        sharedPreferences = getPreferences(MODE_PRIVATE);
        coins = sharedPreferences.getString("coins", "");
        balance.setText(coins);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.AddQuestionBtn:
                intent = new Intent(this, AddQuestionActivity.class);
                startActivity(intent);
                break;
            case R.id.QuestionsBtn:
                intent = new Intent(this, QuestionActivity.class);
                startActivity(intent);
                break;
            case R.id.MyProfileBtn:
                intent = new Intent(this, ProfileActivity.class);
                startActivity(intent);
            case R.id.ChatsBtn:
                intent = new Intent(this, ChatsActivity.class);
                startActivity(intent);
            case R.id.SettingsBtn:
                intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                break;
        }
    }
}
