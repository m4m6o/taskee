package com.m4m6o.taskee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    EditText name, login, passwd;
    Button back, signUp;
    DBHelper dbHelper;
    String nameText, loginText, passwdText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name   = findViewById(R.id.nameInputText);
        login  = findViewById(R.id.loginInputText);
        passwd = findViewById(R.id.passwdInputText);
        back   = findViewById(R.id.backBtn);
        signUp = findViewById(R.id.signUpBtn);

        back.setOnClickListener(this);
        signUp.setOnClickListener(this);

        nameText   = name.getText().toString();
        loginText  = login.getText().toString();
        passwdText = passwd.getText().toString();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.backBtn){
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        } else if (v.getId() == R.id.signUpBtn){
            dbHelper = new DBHelper(this);
            if (dbHelper.checkLogin(loginText)){
                boolean insert = dbHelper.insert(nameText, loginText, passwdText);
                if (insert){
                    Toast.makeText(this, "Registered Successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);

                }
            } else {
                Toast.makeText(this, "login already exists", Toast.LENGTH_LONG).show();
            }
        }
    }
}
